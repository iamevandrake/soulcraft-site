---
okf_version: "0.1"
title: Soulcraft Knowledge Bundle
---

# Soulcraft

A knowledge bundle for Soulcraft, an AI-native marketing agency. It captures who we are and the AEO / GEO / AIO domain we work in, written in the [Open Knowledge Format](/references/okf-spec.md) so humans and agents can read it without translation.

The soul is the system.

# Identity

* [Soulcraft](identity/soulcraft.md) - The organization and where to start.
* [Mission](identity/mission.md) - Why we exist.
* [Voice and Tone](identity/voice-and-tone.md) - How we sound.
* [What We Believe](identity/beliefs.md) - The seven beliefs.
* [Competitive Position](identity/positioning.md) - Where we sit and who we serve.
* [Vision](identity/vision.md) - Where we are going.

# Services

* [SEO / AEO / GEO](services/seo-aeo-geo.md) - Presence in search and AI.
* [Demand and Content Generation](services/demand-generation.md) - The lead engine.
* [AI Advertising](services/ai-advertising.md) - Advertising inside AI platforms.

# Methodology

* [soul.md](methodology/soul-md.md) - The identity artifact at the center.
* [opensoul](methodology/opensoul.md) - The agentic content and demand system.
* [How We Work](methodology/how-we-work.md) - The engagement model.

# Concepts

* [Answer Engine](concepts/answer-engine.md) - The surface that returns synthesized answers.
* [Answer Engine Optimization (AEO)](concepts/aeo.md) - Being surfaced and cited in answers.
* [Generative Engine Optimization (GEO)](concepts/geo.md) - Shaping how models represent you.
* [AI Optimization (AIO)](concepts/aio.md) - The umbrella practice.
* [Agent Readiness](concepts/agent-readiness.md) - Legibility to autonomous agents.
* [EntityMap](concepts/entitymap.md) - Machine-readable entity signals.
* [Citations](concepts/citations.md) - The AI-era equivalent of ranking.

# References

* [Open Knowledge Format v0.1](references/okf-spec.md) - The spec this bundle conforms to.
* [The LLM Wiki Pattern](references/llm-wiki.md) - The pattern OKF formalizes.
* [The Website Specification](references/website-specification.md) - Web best practice for agent readiness.
