---
type: Concept
title: Citations
description: External sources that answer engines quote and link; earning them is central to AI visibility.
tags: [concept, citations, aeo]
timestamp: 2026-06-16T00:00:00Z
---

A citation is a reference an [answer engine](/concepts/answer-engine.md) makes to an external source when it builds an answer. Being cited is the AI-era equivalent of ranking: it is how an engine signals which sources it trusts and sends attention to.

# Why they matter

Citations drive both visibility and credibility. A company cited often, accurately, and in positive context is well represented in AI answers. One that is rarely cited is effectively invisible, regardless of how strong its product is.

# How to earn them

Publish content that is clear, structured, genuinely useful, and easy to quote; strengthen entity signals (see [EntityMap](/concepts/entitymap.md)); and maintain consistency across surfaces. Note that citation presence can be fluid over time, so it is monitored continuously as part of [AEO](/concepts/aeo.md).
