---
type: Concept
title: Agent Readiness
description: How legible a website and its data are to autonomous agents that read, navigate, and act on them.
tags: [concept, agents, web]
timestamp: 2026-06-16T00:00:00Z
---

Agent readiness measures how legible a website and its data are to autonomous agents that read, navigate, and act on them, rather than to human readers alone.

# What it covers

- Clean, structured, parseable content and markup.
- Machine-readable identity and entity signals. See [EntityMap](/concepts/entitymap.md).
- Knowledge published in agent-friendly formats like the [Open Knowledge Format](/references/okf-spec.md).
- Conformance with established web practice. See the [Website Specification](/references/website-specification.md).

# Why it matters

Agents will increasingly become the customers and clients of the future. Speaking their language is part of the work. This bundle is itself an agent-readiness artifact: knowledge about Soulcraft, written for agents to consume directly.
