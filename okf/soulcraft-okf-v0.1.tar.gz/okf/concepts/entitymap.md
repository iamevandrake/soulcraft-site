---
type: Concept
title: EntityMap
description: A machine-readable map of a company's entities and relationships that helps AI systems understand who it is.
resource: https://www.soulcraftagency.com
tags: [concept, entity, aeo]
timestamp: 2026-06-16T00:00:00Z
---

An EntityMap is a machine-readable description of a company's core entities (the organization, people, products, services, concepts) and the relationships between them, published so AI and search systems can understand a company precisely rather than guessing.

# Why it matters

Strong, consistent entity signals reduce the chance that a model invents or distorts facts about you. When information is vague, models fill the gap with the most detailed available story, even a false one. A clear EntityMap is a defense against that failure mode and a boost to [AEO](/concepts/aeo.md) and [GEO](/concepts/geo.md).

# At Soulcraft

EntityMap v1.0 is live on soulcraftagency.com as part of our own [agent readiness](/concepts/agent-readiness.md) work. This OKF bundle complements it: the EntityMap states the entities; the bundle gives agents the prose and relationships behind them.
