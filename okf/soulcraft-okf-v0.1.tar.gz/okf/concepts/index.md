# Concepts

The AEO / GEO / AIO knowledge domain Soulcraft works in.

* [Answer Engine Optimization (AEO)](aeo.md) - The practice of getting a company surfaced and cited in the answers that answer engines return.
* [Agent Readiness](agent-readiness.md) - How legible a website and its data are to autonomous agents that read, navigate, and act on them.
* [AI Optimization (AIO)](aio.md) - The umbrella practice of optimizing a company's presence, accuracy, and sentiment across all AI surfaces.
* [Answer Engine](answer-engine.md) - A system that returns a synthesized answer instead of a list of links: ChatGPT, Perplexity, Google AI overviews, and similar.
* [Citations](citations.md) - External sources that answer engines quote and link; earning them is central to AI visibility.
* [EntityMap](entitymap.md) - A machine-readable map of a company's entities and relationships that helps AI systems understand who it is.
* [Generative Engine Optimization (GEO)](geo.md) - Shaping how generative AI systems represent and recommend a company across their generated output.
