---
type: Concept
title: AI Optimization (AIO)
description: The umbrella practice of optimizing a company's presence, accuracy, and sentiment across all AI surfaces.
tags: [concept, aio, ai]
timestamp: 2026-06-16T00:00:00Z
---

AI Optimization (AIO) is the umbrella practice of optimizing how a company appears across every AI surface: answer engines, generative systems, AI advertising, and the agents that increasingly act on people's behalf.

# What it contains

- [Answer Engine Optimization (AEO)](/concepts/aeo.md): presence and citation in direct answers.
- [Generative Engine Optimization (GEO)](/concepts/geo.md): representation across generated content.
- [Agent readiness](/concepts/agent-readiness.md): making your site and data legible to agents.

# Why it is its own discipline

Traditional SEO optimizes for ranked links. AIO optimizes for synthesis, representation, and recommendation by machines. As agents become customers and clients, per Soulcraft's [beliefs](/identity/beliefs.md), AIO becomes the center of gravity for marketing.
