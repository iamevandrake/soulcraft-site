---
type: Service
title: SEO / AEO / GEO
description: Measure how you show up in search and AI, then run an automated content engine that improves presence and sentiment.
tags: [service, seo, aeo, geo]
timestamp: 2026-06-16T00:00:00Z
---

We measure how you show up in search and in AI answers, then build an automated content engine that improves your presence and sentiment over time.

# What the engine produces

- Internal landing pages
- Blog articles
- Keyword targeting
- Prompt optimization for answer engines

The system runs itself once the foundation is set.

# The disciplines

- [Answer Engine Optimization (AEO)](/concepts/aeo.md): showing up in AI answers.
- [Generative Engine Optimization (GEO)](/concepts/geo.md): shaping how generative systems represent you.
- [AI Optimization (AIO)](/concepts/aio.md): the broader practice across all AI surfaces.

Measurement draws on monitoring tools and our own [EntityMap](/concepts/entitymap.md) work. Everything is grounded in the client's [soul.md](/methodology/soul-md.md).
