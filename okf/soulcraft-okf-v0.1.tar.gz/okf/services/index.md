# Services

What Soulcraft sells across search, demand, and AI surfaces.

* [AI Advertising](ai-advertising.md) - Advertise inside ChatGPT and other AI platforms by connecting product feeds to these emerging services.
* [Demand and Content Generation](demand-generation.md) - The opensoul system creates campaigns and workflows that generate leads, plugged directly into CRM, email, and social.
* [SEO / AEO / GEO](seo-aeo-geo.md) - Measure how you show up in search and AI, then run an automated content engine that improves presence and sentiment.
