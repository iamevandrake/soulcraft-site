---
type: Reference
title: The LLM Wiki Pattern
description: Andrej Karpathy's idea of a living markdown wiki that agents read and maintain, which OKF formalizes.
resource: https://gist.github.com/karpathy/442a6bf555914893e9891c11519de94f
tags: [reference, pattern, agents]
timestamp: 2026-06-16T00:00:00Z
---

The LLM wiki pattern, articulated by Andrej Karpathy, treats knowledge as a living library of markdown files that agents read before doing work and help maintain over time.

The insight: the bookkeeping that causes humans to abandon personal wikis (updating cross-references, touching many files at once) is exactly what language models are good at. They do not get bored and do not forget to update a link.

# Connection to OKF

The same pattern keeps reappearing under different names: Obsidian vaults wired to coding agents, the AGENTS.md and CLAUDE.md family of convention files, repos full of index.md and log.md artifacts. The [Open Knowledge Format](/references/okf-spec.md) formalizes the small set of conventions that let these wikis interoperate.

# Citations

[1] [Karpathy LLM Wiki gist](https://gist.github.com/karpathy/442a6bf555914893e9891c11519de94f)
