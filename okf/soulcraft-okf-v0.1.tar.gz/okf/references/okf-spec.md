---
type: Reference
title: Open Knowledge Format v0.1
description: The open specification this bundle conforms to: knowledge as markdown files with YAML frontmatter.
resource: https://github.com/GoogleCloudPlatform/knowledge-catalog/tree/main/okf
tags: [reference, okf, spec]
timestamp: 2026-06-16T00:00:00Z
---

The Open Knowledge Format (OKF) is an open, vendor-neutral specification for representing knowledge as a directory of markdown files with YAML frontmatter. It was introduced by the Google Cloud Data Cloud team in June 2026.

# The shape

- A bundle is a directory of markdown concept documents.
- Each concept has YAML frontmatter; the only required field is `type`.
- Concepts link to each other with normal markdown links, forming a graph.
- Optional `index.md` files support progressive disclosure; optional `log.md` files record history.

# Why Soulcraft publishes in it

It is readable by humans, parseable by agents without an SDK, diffable in version control, and portable across tools and organizations. That makes it a natural fit for [agent readiness](/concepts/agent-readiness.md) and a clean expression of a [soul.md](/methodology/soul-md.md) as a navigable graph.

# Citations

[1] [Introducing the Open Knowledge Format](https://cloud.google.com/blog/products/data-analytics/how-the-open-knowledge-format-can-improve-data-sharing)
[2] [OKF specification and reference implementation](https://github.com/GoogleCloudPlatform/knowledge-catalog/tree/main/okf)
