---
type: Reference
title: The Website Specification
description: A platform-agnostic specification of what a good website does, useful for agent-readiness and AEO audits.
resource: https://specification.website
tags: [reference, web, agent-readiness]
timestamp: 2026-06-16T00:00:00Z
---

The Website Specification is a platform-agnostic specification of the technical features a good website should carry, each tagged required, recommended, optional, or avoid, and backed by primary sources (WHATWG, W3C, IETF RFCs, IANA, WCAG).

# Why it is here

Soulcraft uses it for [agent readiness](/concepts/agent-readiness.md) and AEO audits: it answers what a site needs to be legible to agents and answer engines, rather than guessing at web best practice. It is queryable by agents through an MCP server and a published agent skill.

# Citations

[1] [specification.website](https://specification.website)
