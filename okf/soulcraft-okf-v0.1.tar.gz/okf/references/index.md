# References

External standards and patterns this bundle builds on.

* [The LLM Wiki Pattern](llm-wiki.md) - Andrej Karpathy's idea of a living markdown wiki that agents read and maintain, which OKF formalizes.
* [Open Knowledge Format v0.1](okf-spec.md) - The open specification this bundle conforms to: knowledge as markdown files with YAML frontmatter.
* [The Website Specification](website-specification.md) - A platform-agnostic specification of what a good website does, useful for agent-readiness and AEO audits.
