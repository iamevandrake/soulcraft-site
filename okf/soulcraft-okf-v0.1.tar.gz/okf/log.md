# Bundle Update Log

## 2026-06-16
* **Initialization**: Established the Soulcraft knowledge bundle and root [index](/index.md) in Open Knowledge Format v0.1.
* **Creation**: Authored identity, services, methodology, concept, and reference documents.
* **Creation**: Added the [Open Knowledge Format](/references/okf-spec.md) and [LLM Wiki](/references/llm-wiki.md) references.
