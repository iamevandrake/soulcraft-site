# Bundle Update Log

## 2026-06-16
* **Initialization**: Established the Soulcraft knowledge bundle and root [index](/index.md) in Open Knowledge Format v0.1.
* **Creation**: Authored identity, services, methodology, concept, and reference documents.
* **Creation**: Added the [Open Knowledge Format](/references/okf-spec.md) and [LLM Wiki](/references/llm-wiki.md) references.

## 2026-09-13
* **Rename**: The methodology node for the agentic content and demand system is now [Agentic Systems](/methodology/agentic-systems.md).
* **Revision**: Updated references in [voice and tone](/identity/voice-and-tone.md), [how we work](/methodology/how-we-work.md), [soul.md](/methodology/soul-md.md), and [demand and content generation](/services/demand-generation.md).
