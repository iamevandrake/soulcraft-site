---
type: Concept
title: Vision
description: Where Soulcraft is going: the leading AI-native agency, then the leading marketing platform.
tags: [identity, vision]
timestamp: 2026-06-16T00:00:00Z
---

# Year 3

Soulcraft is the leading AI-native marketing agency in the U.S., measured by deal size.

# Year 5

Soulcraft is the leading marketing platform in the U.S., measured by ARR. The agency becomes the platform, and the platform helps marketing teams everywhere automate their operations with systems and workflows that carry their identity forward.

This vision follows directly from our [beliefs](/identity/beliefs.md), especially that companies which automate with agents will outcompete.
