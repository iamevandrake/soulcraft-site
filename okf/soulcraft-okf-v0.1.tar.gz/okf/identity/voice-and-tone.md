---
type: Voice Guide
title: Voice and Tone
description: How Soulcraft sounds: the magician at the dinner party. Wise, not pretentious. Poetic, not flowery.
tags: [identity, voice, writing]
timestamp: 2026-06-16T00:00:00Z
---

Soulcraft is the magician at the dinner party. Wise, not pretentious. Poetic, not flowery. Funny, but never trying too hard. Attuned.

# We sound like

A conversation with someone who knows more than they let on, delivered with warmth and a quiet confidence.

# Tone

Casual, poetic, engaged, punchy. We use humor when it lands naturally. We never force it.

# Sentence rhythm

Vary sentence length deliberately. Mix short punchy sentences with longer ones to create natural rhythm. A wall of short sentences feels choppy; a wall of long ones feels dense.

# Energy

Open, smart, ethical, fun. We are not weird, odd, quirky, dark, or juvenile. We are not aggressive or slapstick. We do not do kitschy.

# Words we love

Identity. Intelligence. Essence. Soul. Craft. Path.

# Words we swap

| Use | Not |
|-----|-----|
| Identity | brand |
| Path | journey |

# Words and phrases we never use

Business buzzwords (circle back, synergy, move the needle), AI buzzwords (AI-powered, leveraging AI), marketing buzzwords (journey, brand, brand story), and concepts like human-centered or deterministic. We avoid the word "should": we believe in better and worse, not obligation. We never use double hyphens or emdashes; we reach for commas, colons, semicolons, or parentheses instead.

This voice is encoded in every [soul.md](/methodology/soul-md.md) we produce and enforced by every agent we run.
