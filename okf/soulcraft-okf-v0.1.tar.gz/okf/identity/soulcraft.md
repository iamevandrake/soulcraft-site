---
type: Organization
title: Soulcraft
description: An AI-native marketing agency that builds agentic systems carrying a company's identity forward in everything they do.
resource: https://www.soulcraftagency.com
tags: [identity, agency, about]
timestamp: 2026-06-16T00:00:00Z
---

Soulcraft is an AI-native marketing agency. We build agentic systems that automate marketing end to end, and we build them from the premise that agents do the work while the soul is what makes that work feel human.

Founded in 2026 by Evan Drake, Soulcraft grew out of 20 years at the intersection of technology and marketing (from Apple to Chainlink) and a lifelong obsession with magic: the feeling an audience gets when something impossible just happened. That is the feeling great marketing creates.

# What we believe in one line

The most valuable thing an organization has is its identity, and that identity can be shaped, refined, and tuned. That continuous act of refinement is the craft.

# Start here

- Our reason for existing: [mission](/identity/mission.md)
- How we sound: [voice and tone](/identity/voice-and-tone.md)
- What we hold true: [beliefs](/identity/beliefs.md)
- Where we sit in the market: [positioning](/identity/positioning.md)
- What we sell: [SEO / AEO / GEO](/services/seo-aeo-geo.md), [demand and content generation](/services/demand-generation.md), [AI advertising](/services/ai-advertising.md)
- The artifact at the center of it all: [soul.md](/methodology/soul-md.md)

# Tagline

The soul is the system.
