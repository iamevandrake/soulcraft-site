# Identity

Who Soulcraft is: origin, mission, voice, beliefs, positioning.

* [What We Believe](beliefs.md) - The seven beliefs that ground every decision Soulcraft makes.
* [Mission](mission.md) - Why Soulcraft exists: to give marketing systems an identity and keep them from ever forgetting it.
* [Competitive Position](positioning.md) - Soulcraft sits in a category of one: tools we use, not competitors we fear.
* [Soulcraft](soulcraft.md) - An AI-native marketing agency that builds agentic systems carrying a company's identity forward in everything they do.
* [Voice and Tone](voice-and-tone.md) - How Soulcraft sounds: the magician at the dinner party. Wise, not pretentious. Poetic, not flowery.
