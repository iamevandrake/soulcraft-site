---
type: Principles
title: What We Believe
description: The seven beliefs that ground every decision Soulcraft makes.
tags: [identity, beliefs, principles]
timestamp: 2026-06-16T00:00:00Z
---

1. The customer is always right.
2. Every company, person, and agent has a soul.
3. Companies that automate with agents will outcompete.
4. Originality matters. Content that looks handcrafted by humans is necessary for building trust with humans.
5. Companies that implement agentic processes will scale the fastest.
6. Marketing is increasingly an engineering discipline.
7. Agents will increasingly become the customers and clients of the future. It is important to speak their language too.

Belief seven is why this bundle exists in the [Open Knowledge Format](/references/okf-spec.md): knowledge written for agents to read. Belief two is the foundation of [soul.md](/methodology/soul-md.md).
