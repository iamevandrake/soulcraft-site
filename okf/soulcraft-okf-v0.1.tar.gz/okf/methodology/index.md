# Methodology

How the work gets done: the soul.md artifact, the agentic systems, the engagement model.

* [How We Work](how-we-work.md) - Async support through Slack and Signal, weekly or bi-weekly meetings, agentic systems running continuously in between.
* [Agentic Systems](agentic-systems.md) - Soulcraft's agentic content and demand system that runs campaigns and workflows from a soul.md foundation.
* [soul.md](soul-md.md) - A brand identity document that encodes a company's essence so agents and content systems carry it forward consistently.
