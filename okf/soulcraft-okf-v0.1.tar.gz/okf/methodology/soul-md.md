---
type: Method
title: soul.md
description: A brand identity document that encodes a company's essence so agents and content systems carry it forward consistently.
tags: [method, soul, identity]
timestamp: 2026-06-16T00:00:00Z
---

A soul.md is the identity document at the center of everything Soulcraft builds. It captures a company's origin, mission, voice, beliefs, positioning, and the words it loves and avoids, written so that both humans and agents can read it without translation.

# Why it exists

Identity usually lives in the heads of a few people and leaks out inconsistently. A soul.md makes identity explicit, version-controlled, and machine-readable, so every agent and every piece of content stays in character.

# How it is used

Each agent in our [agentic systems](/methodology/agentic-systems.md) reads the relevant soul.md before producing anything. The result is content that sounds like one company rather than a hundred guessers.

This document is the applied form of our second belief: every company, person, and agent has a soul. See [beliefs](/identity/beliefs.md). The bundle you are reading is itself a soul.md expanded into an [OKF](/references/okf-spec.md) graph.

# Example

Soulcraft's own [voice and tone](/identity/voice-and-tone.md) guide is a slice of our soul.md.
