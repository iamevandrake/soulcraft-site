---
type: Process
title: How We Work
description: Async support through Slack and Signal, weekly or bi-weekly meetings, agentic systems running continuously in between.
tags: [process, engagement]
timestamp: 2026-06-16T00:00:00Z
---

Clients get async support through Slack and Signal. We meet weekly or bi-weekly depending on the level of engagement.

The agentic systems run continuously in between. They develop content based on [soul.md](/methodology/soul-md.md) files and work autonomously to improve demand and generate leads. The human cadence sets direction; the [opensoul](/methodology/opensoul.md) system does the work.
