---
type: System
title: opensoul
description: Soulcraft's agentic content and demand system that runs campaigns and workflows from a soul.md foundation.
tags: [system, agents, automation]
timestamp: 2026-06-16T00:00:00Z
---

opensoul is Soulcraft's agentic system for content and demand. It creates campaigns and workflows, plugs into CRM, email, and social, and produces content continuously from a [soul.md](/methodology/soul-md.md) foundation.

# What it powers

- [Demand and content generation](/services/demand-generation.md)
- The content engine behind [SEO / AEO / GEO](/services/seo-aeo-geo.md)

# The premise

Agents do the work. The soul is what makes that work feel human. Every agent reads the soul.md before acting, which keeps a high volume of output in one consistent identity. This is the engineering discipline view of marketing from our [beliefs](/identity/beliefs.md).
